package com.example.SpringBoot_CRUD_RestAPI_webservices.Controller;

import com.example.SpringBoot_CRUD_RestAPI_webservices.Entity.User;
import com.example.SpringBoot_CRUD_RestAPI_webservices.Service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // combination of @Controller and @ResponseBody.
@AllArgsConstructor
@RequestMapping("api/users")
public class UserController {
    private UserService userService;
    //build create User RESTAPI
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user){
        User savedUser = userService.createUser(user);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    //build get user by RESTAPI
    //http://localhost:8080/api/users/1
    @GetMapping("{id}")
    public ResponseEntity<User> getUserId(@PathVariable("id") Long userId){
        User user = userService.getUserId(userId);
        return new ResponseEntity<>(user,HttpStatus.OK);
    }

    //Build Getall user by RestAPI
    //http://localhost:8080/api/users
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers()
    {
        List<User> users= userService.getAllUsers();
        return new ResponseEntity<>(users,HttpStatus.OK);
    }


    //Build Update User RestAPI
    //http://localhost:8080/api/users/1
    @PutMapping("{id}")
    public ResponseEntity<User> updateUser(@PathVariable("id") Long userId,@RequestBody User user){
        user.setId(userId);
        User updateUser = userService.updateUser(user);
        return new ResponseEntity<>(updateUser,HttpStatus.OK);
    }
    //Build Delete User RestAPI
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") Long userId){
        userService.deleteUser(userId);
        return new ResponseEntity<>("Successfully Deleted",HttpStatus.OK);
    }

}
