package com.example.SpringBoot_CRUD_RestAPI_webservices.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.context.annotation.Primary;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "USERS")// we can add schema and unique_Contriants etc..
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto Increment feature by GenerationType.Identity.
    private Long id;
    @Column(nullable = false)
    private String firstName;
    @Column(nullable = false)
    private String lastName;
    @Column(nullable = false,unique = true)
    private String email;
}
