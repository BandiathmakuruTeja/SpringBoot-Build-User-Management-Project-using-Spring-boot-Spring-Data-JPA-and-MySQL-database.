package com.example.SpringBoot_CRUD_RestAPI_webservices.Repository;

import com.example.SpringBoot_CRUD_RestAPI_webservices.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long>
{
}
