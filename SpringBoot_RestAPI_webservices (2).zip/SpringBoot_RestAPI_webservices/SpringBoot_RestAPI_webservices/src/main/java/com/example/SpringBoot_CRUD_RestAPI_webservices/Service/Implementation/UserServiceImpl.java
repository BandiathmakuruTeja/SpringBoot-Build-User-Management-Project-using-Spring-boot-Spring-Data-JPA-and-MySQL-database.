package com.example.SpringBoot_CRUD_RestAPI_webservices.Service.Implementation;

import com.example.SpringBoot_CRUD_RestAPI_webservices.Entity.User;
import com.example.SpringBoot_CRUD_RestAPI_webservices.Repository.UserRepository;
import com.example.SpringBoot_CRUD_RestAPI_webservices.Service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;


    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User getUserId(Long userID) {
        Optional<User> optionalUser=userRepository.findById(userID);
        return optionalUser.get();
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User updateUser(User user) {
        // Retrieve the existing user from the repository using the user's ID.
        User existingUser = userRepository.findById(user.getId()).get();
        // Update the existing user's fields with the new values
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmail(user.getEmail());
        User updateUser = userRepository.save(existingUser);
        return updateUser;

    }

    @Override
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
}
