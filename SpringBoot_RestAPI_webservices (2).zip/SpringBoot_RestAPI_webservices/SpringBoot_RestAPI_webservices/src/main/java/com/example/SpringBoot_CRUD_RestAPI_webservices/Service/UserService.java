package com.example.SpringBoot_CRUD_RestAPI_webservices.Service;

import com.example.SpringBoot_CRUD_RestAPI_webservices.Entity.User;

import java.util.List;

public interface UserService {
    User createUser(User user);// Method
    User getUserId(Long userID);
    List<User> getAllUsers();
    User updateUser(User user);
    void deleteUser(Long userId);
}

