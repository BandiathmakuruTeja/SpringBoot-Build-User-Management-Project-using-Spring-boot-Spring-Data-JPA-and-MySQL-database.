package com.example.SpringBoot_CRUD_RestAPI_webservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApiWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiWebservicesApplication.class, args);
	}

}
