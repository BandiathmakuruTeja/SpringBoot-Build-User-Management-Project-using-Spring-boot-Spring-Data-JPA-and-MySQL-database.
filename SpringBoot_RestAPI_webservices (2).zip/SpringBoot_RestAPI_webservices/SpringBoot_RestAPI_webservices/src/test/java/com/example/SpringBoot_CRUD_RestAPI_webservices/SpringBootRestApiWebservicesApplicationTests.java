package com.example.SpringBoot_CRUD_RestAPI_webservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestApiWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
